import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-doc',
  standalone: true,
  imports: [],
  templateUrl: './manage-doc.component.html',
  styleUrl: './manage-doc.component.scss'
})
export class ManageDocComponent {

}
