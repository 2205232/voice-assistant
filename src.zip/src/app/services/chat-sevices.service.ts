import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChatSevicesService {

  chats: { id: number; name: string }[] = []; // Stores active chats
  chatLimit = 5;

  addNewChat() {
    if (this.chats.length < this.chatLimit) {
      const newChatId = this.chats.length + 1;
      alert(newChatId);
      //this.chats.push('id': newChatId);
    } else {
      alert('You have reached the limit of 5 chats.');
    }
  }

  getChats() {
    return this.chats;
  }

  getChatLimit() {
    return this.chatLimit;
  }
}
